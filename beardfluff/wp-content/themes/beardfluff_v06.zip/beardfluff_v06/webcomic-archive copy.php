<?php
/**
 * Template Name: Webcomic Archive
 */
?>

<?php get_header(); ?>

<div class="cols group">

	<?php get_sidebar('primary'); ?>
	<div class="hfeed col col-9" role="main">
		<h1><?php the_title(); ?></h1>
		<section id="post-<?php the_id(); ?>" <?php post_class(); ?>>	  
			<?php
			  edit_post_link( __( 'Edit'), '<div class="button">', '</div>' );
			?>
			
			<nav class="archive col col-3">
				<ul>
					<li><a href="#archive-search">Search the comics</a></li>
					<li><a href="#archive-dropdown">Browse by title</a></li>
					<li><a href="#archive-monthly">Browse by month</a></li>
					<li><a href="#archive-thumbs">Browse by thumbnail</a></li>
				</ul>
			</nav>
			
			<section id="archive-search" class="search col col-6">
				<h1>Search the comics</h1>
				<div class="col col-6 last">
					<?php get_search_form(); ?>
				</div>
			</section>
			
			<section id="archive-dropdown" class="dropdown col col-6">
				<h1>Browse by title</h1>
				<div class="col col-6 last">
					<?php
						webcomic_archive( 'last_only=1&group=month&format=dropdown&order=DESC&show_count=true' ); //drowpdown
					?>
				</div>
			</section> 

			<section id="archive-monthly" class="monthly cols group">
				<h1>Browse by month</h1>
				<?php
			webcomic_archive( 'last_only=1&group=month&format=grid&order=DESC&show_count=true' ); //normal monthly lists
				?>
			</section> 
		
			<section id="archive-thumbs" class="thumbs cols group">
				<h1>Browse by thumbnail</h1>
				<a class="top" href="#content">Back to top</a>
				<?php
			webcomic_archive( 'last_only=1&group=month&format=grid&image=small&order=DESC&show_count=true' ); //images in montly lists
				?>
			</section> 
		
			
		</section><!-- //post<?php the_ID(); ?> -->
		
		<?php 
			wp_link_pages( array( 'before' => '<nav class="paged">' . __( 'Pages:', 'archimedes' ), 'after' => '</nav>' ) );
		?>
	
	</div><!-- //hfeed -->

</div><!-- //cols -->

<?php get_footer(); ?>