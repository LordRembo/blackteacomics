<aside class="secundary col col-3" role="complementary">
	<?php if ( !dynamic_sidebar( 'secundary-aside' ) ) { //see functions.php hook_init ?>
    fjsqdfjsqdfsjkfdfjkqd
  <?php } ?>
</aside>