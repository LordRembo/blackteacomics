<div class="ads ads-tertiary">
	<h3>Other comics</h3>
	<iframe class="scribol" height="210" width="440" id="scribol_363859" scrolling="no" frameborder="0"></iframe>
	<script>
	var Scribol;
	if(typeof Scribol=='undefined'){Scribol={};  Scribol.frames=[];Scribol.site='http://scribol.com/';Scribol.is_preview=false;}
	Scribol.frames.push('363859');</script>
	<script async="async" defer="defer" src="http://scribol.com/txwidget1.2.js"></script>  
 	  
	<?php if ( !dynamic_sidebar( 'tertiary ads' ) ) { //see functions.php hook_init ?>
  <?php } ?>
</div>