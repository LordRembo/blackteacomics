<!doctype html>  
<html lang="en" class="no-js">
<head>
	<meta charset="utf-8" />
	<meta name="author" content="Rembrand Le Compte" />
	<title>Beardfluff | Maintenance</title>
	  <meta name="description" content="comics by Rembrand Le Compte" />
	  <style>
	  	body {
			font: 1em/1.5em Arial, Helvetica, sans-serif;
			background: #efefef;
			color: #3b2300;
			padding: 20px;
		}
		span {
			font-size: 1.2em;
		}
		
		a {
			color: #f90;
		}
		
		ul {
			
		}
		
	  </style>
</head>

<body>

<h1>Maintenance in progress</h1>
<p>Sorry for the trouble, we should be back shortly though.</p>
<ul>
	<h2>In the meantime, you could:</h2>
	<li>Follow us <a href="http://twitter.com/beardfluff" target="_blank">on Twitter</a> or <a href="http://facebook.com/Beardfluff" target="_blank">Facebook</a> to see when we&#8217;re back</li>
	<li>Look at some of the comics on <a href="http://papersnips.tumblr.com" target="_blank">the blog</a></li>
</ul></p>

</body>

</html>