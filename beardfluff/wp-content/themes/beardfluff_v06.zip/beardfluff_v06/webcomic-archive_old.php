<?php
/**
 * Template Name: Webcomic Archive
 */
?>

<?php get_header(); ?>

<div class="cols group">

	<?php get_sidebar('primary'); ?>
	<div class="hfeed col col-9" role="main">
		<h1><?php the_title(); ?></h1>
		<section id="post-<?php the_id(); ?>" <?php post_class(); ?>>	  
			<?php
			  edit_post_link( __( 'Edit'), '<div class="button">', '</div>' );
			?>
			
			<nav class="archive">
				<ul class="group">
					<li><a href="#archive-search">Search</a></li>
					<li><a href="#archive-dropdown">Browse</a></li>
					<li><a href="#archive-monthly">Months</a></li>
					<li><a href="#archive-thumbs">Thumbnails</a></li>
				</ul>
			</nav>
			
			<section id="archive-search" class="search">
				<h1>Search the comics</h1>
				
				<div id="cse" style="width: 100%;">Loading</div>
				<script src="//www.google.com/jsapi" type="text/javascript"></script>
				<script type="text/javascript"> 
				  google.load('search', '1', {language : 'en', style : google.loader.themes.MINIMALIST});
				  google.setOnLoadCallback(function() {
				    var customSearchControl = new google.search.CustomSearchControl('006759437216104904064:243cigcm3me');
				    customSearchControl.setResultSetSize(google.search.Search.FILTERED_CSE_RESULTSET);
				    customSearchControl.draw('cse');
				  }, true);
				</script>

			</section>
			
			<section id="archive-dropdown" class="dropdown">
				<h1>Browse by title</h1>
				<?php
					webcomic_archive( 'last_only=1&group=month&format=dropdown&order=DESC&show_count=true' ); //drowpdown
				?>
			</section> 

			<section id="archive-monthly" class="monthly cols group">
				<h1>Browse by month</h1>
				<?php
			webcomic_archive( 'last_only=1&group=month&format=grid&order=DESC&show_count=true' ); //normal monthly lists
				?>
			</section> 
		
			<section id="archive-thumbs" class="thumbs cols group">
				<h1>Browse by thumbnail</h1>
				<a class="top" href="#content">Back to top</a>
				<?php
			webcomic_archive( 'last_only=1&group=month&format=grid&image=small&order=DESC&show_count=true' ); //images in montly lists
				?>
			</section> 
		
			
		</section><!-- //post<?php the_ID(); ?> -->
		
		<?php 
			wp_link_pages( array( 'before' => '<nav class="paged">' . __( 'Pages:', 'archimedes' ), 'after' => '</nav>' ) );
		?>
	
	</div><!-- //hfeed -->

</div><!-- //cols -->

<?php get_footer(); ?>