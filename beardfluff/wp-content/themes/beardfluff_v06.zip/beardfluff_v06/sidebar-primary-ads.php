<aside class="ads ads-primary">
	<?php if ( !dynamic_sidebar( 'primary ads' ) ) { //see functions.php hook_init ?>
  <?php } ?>  
</aside>