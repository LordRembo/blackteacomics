	<?php if ( !dynamic_sidebar( 'primary-aside' ) ) { //see functions.php hook_init ?>
	jmdfjsqjqdfjsqdfjsqfs
  <?php } ?>
